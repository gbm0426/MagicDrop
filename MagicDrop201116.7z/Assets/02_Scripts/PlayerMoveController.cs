﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMoveController : MonoBehaviour
{
    Vector3 currentPos;



    void Start()
    {
        currentPos = this.gameObject.transform.position;
    }

    void Update()
    {
        Vector3 pos = Camera.main.WorldToViewportPoint(transform.position);

        if(pos.x < 0.05f)
        {
            pos.x = 0.05f;
        }
        else if(pos.x > 0.74f)
        {
            pos.x = 0.74f;
        }

        transform.position = Camera.main.ViewportToWorldPoint(pos);
    }

    //Touch -> Drag -> Move
    void OnMouseDrag()
    {
        Debug.Log("드래그중!");
        Vector3 mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);

        transform.position = new Vector3(mousePosition.x, currentPos.y, 10);
    }

    //Drag End
    void OnMouseUp()
    {
        Debug.Log("드래그끝!");

        //GameLogic Script -> TamaDrop Play
        GameObject.Find("GameLogic").GetComponent<GameLogic>().TamaDrop();
    }
}
