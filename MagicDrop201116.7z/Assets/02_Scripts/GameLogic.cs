﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameLogic : MonoBehaviour
{
    //Player
    public GameObject objPlayer;

    //TamaSelect -> Character Carry Tama Transform
    public Transform carryTamaPos;
    public GameObject parentTamaPos;

    //carryed tama number   0=red , 1=yellow , 2=blue , 3=green , 5=null(reset)
    public int carryNum;
    bool checkCarry;    //true=carry   , false=not carry

    public List<GameObject> TamaList = new List<GameObject>();
    public List<Transform> TamaRespawnList = new List<Transform>();
    public List<GameObject> TamaSpawnedList = new List<GameObject>();
    public List<int> TamaNumList = new List<int>();
    public List<GameObject> TamaCarryList = new List<GameObject>();






    void Start()
    {
        ResetAll();
    }

    void Update()
    {
        
    }

    //ResetAll                         (void Start)
    void ResetAll()
    {
        carryNum = 5;
        checkCarry = false;

        TamaRespawn();
    }

    //Respawn Tama Start               (void Start)
    void TamaRespawn()
    {
        for (int i = 63; i < 84; i++)
        {
            int z = (Random.Range(0, 4));

            Transform targetPoint = TamaRespawnList[i];
            GameObject newTama = Instantiate(TamaList[z]);
            newTama.transform.position = targetPoint.position;
            TamaSpawnedList[i] = newTama;
            TamaNumList[i] = z;
        }
    }

    //TamaSelect
    public void BtnTamaSelect_0()
    {
        carryNum = TamaNumList[77];
        TamaCarryList[0] = (TamaSpawnedList[77]);
        Destroy(TamaSpawnedList[77]);

        //Move Player
        objPlayer.transform.position = new Vector3(-2.5f, -4.5f, 0);

        //Carry Tama -> Children add
        GameObject.Instantiate(TamaCarryList[0], carryTamaPos.position, Quaternion.identity).transform.parent = parentTamaPos.transform;

        checkCarry = true;
    }

    //Drag End -> Tama Drop
    public void TamaDrop()
    {
        if(checkCarry == true)
        {
            Debug.Log("TTTTTTTTTTTTT");
        }
        else if(checkCarry == false)
        {

        }
    }
}
