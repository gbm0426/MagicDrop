﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SceneManager : MonoBehaviour
{




    void Start()
    {
        Screen.SetResolution(720, 1280, false);
    }

    void Update()
    {
        
    }
}
